package com.cognizant.ormlearn.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class StockTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
