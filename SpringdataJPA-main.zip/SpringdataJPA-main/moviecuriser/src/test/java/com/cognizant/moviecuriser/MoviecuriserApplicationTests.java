package com.cognizant.moviecuriser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
/**
 * 
 * @author Ayush Srivastava
 *
 */
@SpringBootTest
class MoviecuriserApplicationTests {

	@Test
	void contextLoads() {
	}

}
